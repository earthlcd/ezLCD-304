﻿Read_me.txt
ezLCD-301 Initial Release 1.0A 9/16/11


Access the ezLCD-301 Users Manual at   
   http://store.earthlcd.com/ezLCD-301                      
 
For technical support, please email:
   support301@earthlcd.com   Subject: ezLCD-301        

